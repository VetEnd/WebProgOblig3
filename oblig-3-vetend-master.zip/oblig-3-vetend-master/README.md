OsloMet brukernavn:s354418

GitHub brukernavn: Vetend

GitHub repo URL: https://github.com/DATA1700/oblig-3-vetend

URL til Heroku app: https://webprog-oblig3-vetend.herokuapp.com

Fullt navn: Vetle Endrerud

Kort beskrivelse av applikasjon (5–10 setninger): Applikasjonen tar inn data som brukeren taster inn i innput boksene. 
Deretter lagrer den dataen inn i et array og oppretter en tabell for dataen. 
Etter brukrer trykk bestill biletter så fjernes teksten fra input boksen.
Applikasjonen har også en slett mulighet for å slette alt dataen i tabellen.